// AutoTyper Popup Script

const $ = id => document.getElementById(id);

// ── State ─────────────────────────────────────────────────────────────────
let appState = 'idle'; // idle | typing | paused
let typoMode = false;
let currentTabId = null;

// ── Helpers ───────────────────────────────────────────────────────────────
function showAlert(msg, type = 'error') {
  const el = $('alert');
  el.textContent = msg;
  el.className = 'alert ' + type;
  if (type === 'info') setTimeout(() => { el.className = 'alert'; }, 2500);
}
function clearAlert() { $('alert').className = 'alert'; }

function setUIState(state) {
  appState = state;
  $('action-row-idle').style.display = state === 'idle' ? 'flex' : 'none';
  $('action-row-typing').style.display = state === 'typing' ? 'flex' : 'none';
  $('action-row-paused').style.display = state === 'paused' ? 'flex' : 'none';

  const pill = $('status-pill');
  pill.textContent = state.toUpperCase();
  pill.className = 'status-pill' + (state !== 'idle' ? ' ' + (state === 'paused' ? 'paused' : 'active') : '');

  $('progress-section').className = 'progress-section' + (state !== 'idle' ? ' visible' : '');
}

function updateProgress(charsTyped, total) {
  const pct = total ? Math.round((charsTyped / total) * 100) : 0;
  $('progress-bar').style.width = pct + '%';
  $('progress-chars').textContent = `${charsTyped.toLocaleString()} / ${total.toLocaleString()} chars`;
  $('progress-pct').textContent = pct + '%';
}

async function getActiveDocsTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      const tab = tabs[0];
      if (tab && tab.url && tab.url.includes('docs.google.com/document')) {
        resolve(tab);
      } else {
        resolve(null);
      }
    });
  });
}

async function sendToContent(msg) {
  if (!currentTabId) {
    const tab = await getActiveDocsTab();
    if (!tab) return { ok: false, error: 'No Google Doc open' };
    currentTabId = tab.id;
  }
  return new Promise(resolve => {
    chrome.tabs.sendMessage(currentTabId, msg, resp => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(resp || { ok: false, error: 'No response' });
      }
    });
  });
}

// ── Tab switching ─────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $('tab-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'templates') renderTemplates();
    if (tab.dataset.tab === 'history') renderHistory();
  });
});

// ── Text input & char count ───────────────────────────────────────────────
$('text-input').addEventListener('input', () => {
  $('char-count').textContent = $('text-input').value.length.toLocaleString();
  clearAlert();
});

// ── WPM Slider ────────────────────────────────────────────────────────────
$('wpm-slider').addEventListener('input', function () {
  $('wpm-display').textContent = this.value + ' WPM';
});

// ── Typo toggle ───────────────────────────────────────────────────────────
$('toggle-typo').addEventListener('click', () => {
  typoMode = !typoMode;
  $('typo-toggle').classList.toggle('on', typoMode);
});

// ── Paste from clipboard ──────────────────────────────────────────────────
$('btn-paste').addEventListener('click', async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text) {
      $('text-input').value = text;
      $('char-count').textContent = text.length.toLocaleString();
      showAlert('Clipboard pasted ✓', 'info');
    }
  } catch {
    showAlert('Clipboard access denied. Paste manually with Ctrl+V.');
  }
});

// ── File import ───────────────────────────────────────────────────────────
$('btn-file').addEventListener('click', () => $('file-input').click());
$('file-input').addEventListener('change', function () {
  const file = this.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    $('text-input').value = e.target.result;
    $('char-count').textContent = e.target.result.length.toLocaleString();
    showAlert(`Imported: ${file.name}`, 'info');
  };
  reader.readAsText(file);
  this.value = '';
});

// ── Start typing ──────────────────────────────────────────────────────────
$('btn-start').addEventListener('click', async () => {
  const text = $('text-input').value.trim();
  if (!text) { showAlert('Please enter some text first.'); return; }

  const tab = await getActiveDocsTab();
  if (!tab) {
    showAlert('Open a Google Doc in this window first, then click Start.');
    return;
  }
  currentTabId = tab.id;

  // Ensure content script is injected (in case of MV3 service worker restart)
  try {
    await chrome.scripting.executeScript({
      target: { tabId: currentTabId },
      files: ['content.js'],
    });
  } catch (_) { /* already injected */ }

  const resp = await sendToContent({
    type: 'START_TYPING',
    text,
    wpm: parseInt($('wpm-slider').value),
    typoMode,
  });

  if (!resp.ok) {
    showAlert(resp.error || 'Failed to start. Make sure a Google Doc is focused.');
    return;
  }

  clearAlert();
  setUIState('typing');
  updateProgress(0, resp.total);

  // Save to history
  saveHistory(text);
});

// ── Pause ─────────────────────────────────────────────────────────────────
$('btn-pause').addEventListener('click', async () => {
  await sendToContent({ type: 'PAUSE_TYPING' });
  setUIState('paused');
});

// ── Resume ────────────────────────────────────────────────────────────────
$('btn-resume').addEventListener('click', async () => {
  const resp = await sendToContent({ type: 'RESUME_TYPING' });
  if (resp.ok) setUIState('typing');
});

// ── Stop ──────────────────────────────────────────────────────────────────
async function stopTyping() {
  await sendToContent({ type: 'STOP_TYPING' });
  setUIState('idle');
  updateProgress(0, 0);
  currentTabId = null;
}
$('btn-stop').addEventListener('click', stopTyping);
$('btn-stop2').addEventListener('click', stopTyping);

// ── Listen for progress / complete messages ───────────────────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'TYPING_PROGRESS') {
    updateProgress(msg.charsTyped, msg.total);
  }
  if (msg.type === 'TYPING_COMPLETE') {
    setUIState('idle');
    updateProgress(msg?.total || 0, msg?.total || 0);
    showAlert('Typing complete ✓', 'info');
    currentTabId = null;
  }
});

// ── Templates ─────────────────────────────────────────────────────────────
function getTemplates() {
  return new Promise(resolve => {
    chrome.storage.local.get('templates', d => resolve(d.templates || []));
  });
}
function saveTemplates(arr) {
  return new Promise(resolve => chrome.storage.local.set({ templates: arr }, resolve));
}

$('btn-save-template').addEventListener('click', async () => {
  const text = $('text-input').value.trim();
  if (!text) { showAlert('Nothing to save.'); return; }
  const name = prompt('Template name:');
  if (!name) return;
  const templates = await getTemplates();
  templates.unshift({ name, text, created: Date.now() });
  await saveTemplates(templates);
  showAlert(`Saved as "${name}" ✓`, 'info');
});

async function renderTemplates() {
  const templates = await getTemplates();
  const list = $('template-list');
  const empty = $('template-empty');
  list.innerHTML = '';
  if (!templates.length) { empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  templates.forEach((t, i) => {
    const item = document.createElement('div');
    item.className = 'template-item';
    item.innerHTML = `
      <div class="template-meta">
        <div class="template-name">${escHtml(t.name)}</div>
        <div class="template-preview">${escHtml(t.text.slice(0, 60))}${t.text.length > 60 ? '…' : ''}</div>
      </div>
      <span class="template-del" title="Delete">✕</span>
    `;
    item.addEventListener('click', e => {
      if (e.target.classList.contains('template-del')) return;
      $('text-input').value = t.text;
      $('char-count').textContent = t.text.length.toLocaleString();
      document.querySelector('.tab[data-tab="type"]').click();
      showAlert(`Loaded "${t.name}" ✓`, 'info');
    });
    item.querySelector('.template-del').addEventListener('click', async () => {
      const tpls = await getTemplates();
      tpls.splice(i, 1);
      await saveTemplates(tpls);
      renderTemplates();
    });
    list.appendChild(item);
  });
}

// ── History ───────────────────────────────────────────────────────────────
function getHistory() {
  return new Promise(resolve => {
    chrome.storage.local.get('history', d => resolve(d.history || []));
  });
}
function saveHistory(text) {
  getHistory().then(history => {
    history.unshift({ text, chars: text.length, time: Date.now() });
    if (history.length > 20) history.length = 20;
    chrome.storage.local.set({ history });
  });
}

async function renderHistory() {
  const history = await getHistory();
  const list = $('history-list');
  const empty = $('history-empty');
  list.innerHTML = '';
  if (!history.length) { empty.style.display = 'block'; return; }
  empty.style.display = 'none';
  history.forEach(h => {
    const item = document.createElement('div');
    item.className = 'history-item';
    const d = new Date(h.time);
    const fmt = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    item.innerHTML = `
      <div class="history-time">${fmt}</div>
      <div class="history-text">${escHtml(h.text.slice(0, 80))}${h.text.length > 80 ? '…' : ''}</div>
      <div class="history-chars">${h.chars.toLocaleString()} chars</div>
    `;
    item.addEventListener('click', () => {
      $('text-input').value = h.text;
      $('char-count').textContent = h.text.length.toLocaleString();
      document.querySelector('.tab[data-tab="type"]').click();
      showAlert('Loaded from history ✓', 'info');
    });
    list.appendChild(item);
  });
}

// ── Utils ─────────────────────────────────────────────────────────────────
function escHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ── Init: restore status if already typing ────────────────────────────────
(async () => {
  const tab = await getActiveDocsTab();
  if (!tab) return;
  currentTabId = tab.id;
  const resp = await sendToContent({ type: 'GET_STATUS' }).catch(() => null);
  if (!resp) return;
  if (resp.isTyping && !resp.isPaused) {
    setUIState('typing');
    updateProgress(resp.charsTyped, resp.total);
  } else if (resp.isPaused) {
    setUIState('paused');
    updateProgress(resp.charsTyped, resp.total);
  }
})();
