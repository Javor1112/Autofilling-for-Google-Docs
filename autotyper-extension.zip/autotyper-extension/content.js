// AutoTyper Content Script
// Injected into Google Docs pages — handles all typing logic

(function () {
  if (window.__autoTyperLoaded) return;
  window.__autoTyperLoaded = true;

  let state = {
    isTyping: false,
    isPaused: false,
    queue: [],
    queueIndex: 0,
    timeoutId: null,
    wpm: 60,
    typoMode: false,
  };

  // Get the Docs keyboard-event iframe
  function getDocsIframe() {
    return document.querySelector('.docs-texteventtarget-iframe');
  }

  // Insert a single printable character using ONLY InputEvent.
  // Google Docs handles insertText itself — DO NOT also fire keydown/keypress
  // for printable chars or every character will be doubled.
  function insertChar(char, iframeDoc) {
    const target = iframeDoc.activeElement || iframeDoc.body;

    target.dispatchEvent(new InputEvent('beforeinput', {
      inputType: 'insertText',
      data: char,
      bubbles: true,
      cancelable: true,
    }));

    target.dispatchEvent(new InputEvent('input', {
      inputType: 'insertText',
      data: char,
      bubbles: true,
    }));
  }

  // Fire a special key (Enter, Tab, Backspace) using KeyboardEvent only.
  // These are structural keys that Docs handles via keydown — NOT via InputEvent.
  function fireSpecialKey(key, code, keyCode, iframeDoc) {
    ['keydown', 'keyup'].forEach(type => {
      iframeDoc.dispatchEvent(new KeyboardEvent(type, {
        key,
        code,
        keyCode,
        which: keyCode,
        bubbles: true,
        cancelable: true,
      }));
    });
  }

  // Dispatch one character from the queue into the Docs iframe
  function fireChar(char) {
    const iframe = getDocsIframe();
    if (!iframe || !iframe.contentDocument) {
      console.warn('[AutoTyper] Docs iframe not found — retrying next tick');
      return;
    }
    const iframeDoc = iframe.contentDocument;

    switch (char) {
      case '\n':
        fireSpecialKey('Enter', 'Enter', 13, iframeDoc);
        break;
      case '\t':
        fireSpecialKey('Tab', 'Tab', 9, iframeDoc);
        break;
      case 'BACKSPACE':
        fireSpecialKey('Backspace', 'Backspace', 8, iframeDoc);
        break;
      default:
        insertChar(char, iframeDoc);
    }
  }

  // Typo engine: randomly introduces and self-corrects typos
  function maybeAddTypo(char) {
    if (!state.typoMode || Math.random() > 0.05) return [char];
    const neighbors = {
      a:'sqwz', b:'vghn', c:'xdfv', d:'serf', e:'wsr', f:'dgre',
      g:'fhty', h:'gjyu', i:'uok', j:'hkui', k:'jloi', l:'kop',
      m:'nkj', n:'bmh', o:'ipk', p:'ol', q:'wa', r:'etf', s:'adze',
      t:'rgy', u:'yhi', v:'cbf', w:'qes', x:'zsdc', y:'tuh', z:'sx'
    };
    const pool = neighbors[char.toLowerCase()];
    if (!pool) return [char];
    const typo = pool[Math.floor(Math.random() * pool.length)];
    return [typo, 'BACKSPACE', char];
  }

  // ms between characters at the configured WPM (5 chars per word, plus jitter)
  function charDelay() {
    const base = 60000 / (state.wpm * 5);
    return base * (0.7 + Math.random() * 0.6);
  }

  // Main typing loop — one character per tick
  function typeNext() {
    if (state.isPaused || !state.isTyping) return;

    if (state.queueIndex >= state.queue.length) {
      state.isTyping = false;
      state.queue = [];
      state.queueIndex = 0;
      chrome.runtime.sendMessage({ type: 'TYPING_COMPLETE' }).catch(() => {});
      return;
    }

    const char = state.queue[state.queueIndex++];
    fireChar(char);

    chrome.runtime.sendMessage({
      type: 'TYPING_PROGRESS',
      charsTyped: state.queueIndex,
      total: state.queue.length,
    }).catch(() => {});

    const delay = char === 'BACKSPACE' ? charDelay() * 0.4 : charDelay();
    state.timeoutId = setTimeout(typeNext, delay);
  }

  function buildQueue(text) {
    const chars = [];
    for (const char of text) {
      chars.push(...(state.typoMode ? maybeAddTypo(char) : [char]));
    }
    return chars;
  }

  // Message handler
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    switch (msg.type) {

      case 'START_TYPING': {
        if (state.isTyping) {
          sendResponse({ ok: false, error: 'Already typing' });
          return true;
        }

        state.wpm = msg.wpm || 60;
        state.typoMode = msg.typoMode || false;
        state.queue = buildQueue(msg.text);
        state.queueIndex = 0;
        state.isTyping = true;
        state.isPaused = false;

        // Focus the iframe so it receives our events
        const iframe = getDocsIframe();
        if (iframe && iframe.contentDocument) {
          iframe.contentDocument.body?.focus();
        }

        setTimeout(typeNext, 400);
        sendResponse({ ok: true, total: state.queue.length });
        break;
      }

      case 'PAUSE_TYPING': {
        state.isPaused = true;
        if (state.timeoutId) clearTimeout(state.timeoutId);
        sendResponse({ ok: true });
        break;
      }

      case 'RESUME_TYPING': {
        if (!state.isTyping) {
          sendResponse({ ok: false, error: 'Not typing' });
          return true;
        }
        state.isPaused = false;
        typeNext();
        sendResponse({ ok: true });
        break;
      }

      case 'STOP_TYPING': {
        state.isTyping = false;
        state.isPaused = false;
        state.queue = [];
        state.queueIndex = 0;
        if (state.timeoutId) clearTimeout(state.timeoutId);
        sendResponse({ ok: true });
        break;
      }

      case 'GET_STATUS': {
        sendResponse({
          isTyping: state.isTyping,
          isPaused: state.isPaused,
          charsTyped: state.queueIndex,
          total: state.queue.length,
        });
        break;
      }

      default:
        sendResponse({ ok: false, error: 'Unknown message' });
    }
    return true;
  });

  console.log('[AutoTyper] Content script loaded ✓');
})();
